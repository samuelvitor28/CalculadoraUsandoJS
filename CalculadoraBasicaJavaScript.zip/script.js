function calculadora()
{
  var confirmacao = confirm("Você quer realizar uma nova operação?");
 
  while(confirmacao)
    {
      alert ('Digite dois valores:');
      var num1 = prompt ('Digite seu primeiro valor: ');
      var num2 = prompt ('Digite seus segundo valor: ');

      let n1 = parseInt(num1);
      let n2 = parseInt(num2);

      var opcao = prompt ("Escolha uma opção: \n+ para soma\n- para subtasção\n* para multiplicação\n/ para divisão");

      if (opcao == '+')
      {
        var resultado = n1 + n2;

        alert (resultado.toFixed(0));

        var res = document.getElementById("res");
        res.innerHTML = resultado.toFixed(0);
        confirmacao = confirm("Você quer realizar uma nova operação?");
      }
      else if (opcao == '-')
      {
        var resultado = n1 - n2;
        alert("O resultado é: " + resultado);
        var res = document.getElementById("res");
        res.innerHTML = resultado.toFixed(0);
        confirmacao = confirm("Você quer realizar uma nova operação?");
      }
      else if (opcao == '*')
      {
        var resultado = n1 * n2;
        alert("O resultado é: " + resultado);
        var res = document.getElementById("res");
        res.innerHTML = resultado.toFixed(0);
        confirmacao = confirm("Você quer realizar uma nova operação?");
      }
      else if (opcao == '/')
      {
        if (n1 == 0 || n2 == 0)
        {
          alert('Não existe divisão por 0!');
          confirmacao = confirm("Você quer realizar uma nova operação?");
        }
        var resultado = n1 / n2;
        alert("O resultado é: " + resultado.toFixed(2));
        var res = document.getElementById("res");
        res.innerHTML = resultado.toFixed(2);
        confirmacao = confirm("Você quer realizar uma nova operação?");
      }
      

      
      

      
    }
}